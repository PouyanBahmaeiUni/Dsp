import numpy as np
import matplotlib.pyplot as plt

def trigonometric_expansion(x, Q):
    """تابع بسط مثلثاتی (FEB)"""
    g = np.zeros(Q)
    g[0] = x
    for p in range(1, (Q + 1) // 2):
        g[2*p - 1] = np.sin(p * np.pi * x)
        g[2*p]     = np.cos(p * np.pi * x)
    return g

def run_simulation():
    # ==========================================
    # ۱. تنظیمات سیستم و سیگنال‌ها
    # ==========================================
    N = 4000         # تعداد نمونه‌ها
    Q = 7            # مرتبه بسط غیرخطی
    M = 8            # مرتبه فیلتر خطی
    
    # مقادیر اندازه گام (تنظیم شده برای MSE حالت پایدار یکسان)
    mu_tflaf = 0.0005
    mu_w = 0.004
    mu_a = 0.2
    
    # وزن‌های بهینه سیستم واقعی
    a_opt = np.array([1, 0.2, 0.5, 0.4, 0.7, 0.1, 0.3])
    w_opt = np.array([1, 0, 0.9, 0, -0.4, 0, 0.6, -0.15])
    
    # تولید ورودی و سیگنال مطلوب
    x = np.random.randn(N)
    g_all = np.array([trigonometric_expansion(xi, Q) for xi in x])
    s_opt = g_all @ a_opt
    
    d_clean = np.zeros(N)
    for n in range(M - 1, N):
        s_vec = s_opt[n - M + 1 : n + 1][::-1] 
        d_clean[n] = w_opt @ s_vec
        
    # افزودن نویز (SNR = 30 dB)
    signal_power = np.var(d_clean)
    noise_power = signal_power / (10 ** (30 / 10))
    d = d_clean + np.sqrt(noise_power) * np.random.randn(N)
    
    # آرایه‌های ذخیره خطا برای مقایسه
    mse_tflaf = np.zeros(N)
    mse_hbo = np.zeros(N)
    
    # ==========================================
    # ۲. مقداردهی اولیه فیلترها
    # ==========================================
    # فیلتر TFLAF
    w_tflaf = np.zeros(M)
    a_tflaf = np.zeros(Q)
    a_tflaf[0] = 1.0
    s_buf_tflaf = np.zeros(M)
    G_buf_tflaf = np.zeros((Q, M))
    
    # فیلتر HBO-TFLAF
    w_hbo = np.zeros(M)
    a_hbo = np.zeros(Q)
    a_hbo[0] = 1.0
    s_buf_hbo = np.zeros(M)
    G_buf_hbo = np.zeros((Q, M))
    
    # ==========================================
    # ۳. حلقه اصلی اجرای الگوریتم‌ها
    # ==========================================
    for n in range(N):
        g_n = g_all[n]
        
        # --- TFLAF ---
        G_buf_tflaf = np.roll(G_buf_tflaf, shift=1, axis=1)
        G_buf_tflaf[:, 0] = g_n
        s_n_tfl = a_tflaf @ g_n
        s_buf_tflaf = np.roll(s_buf_tflaf, shift=1)
        s_buf_tflaf[0] = s_n_tfl
        
        y_n_tfl = w_tflaf @ s_buf_tflaf
        e_n_tfl = d[n] - y_n_tfl
        
        w_tflaf = w_tflaf + mu_tflaf * e_n_tfl * s_buf_tflaf
        a_tflaf = a_tflaf + mu_tflaf * e_n_tfl * (G_buf_tflaf @ w_tflaf)
        mse_tflaf[n] = e_n_tfl ** 2
        
        # --- HBO-TFLAF ---
        G_buf_hbo = np.roll(G_buf_hbo, shift=1, axis=1)
        G_buf_hbo[:, 0] = g_n
        s_n_hbo = a_hbo @ g_n
        s_buf_hbo = np.roll(s_buf_hbo, shift=1)
        s_buf_hbo[0] = s_n_hbo
        
        y_n_hbo = w_hbo @ s_buf_hbo
        e_n_hbo = d[n] - y_n_hbo
        
        w_hbo = w_hbo + mu_w * e_n_hbo * s_buf_hbo
        a_hbo = a_hbo + mu_a * e_n_hbo * (G_buf_hbo @ w_hbo)
        mse_hbo[n] = e_n_hbo ** 2

    # ==========================================
    # ۴. هموارسازی و رسم نمودار منحنی یادگیری
    # ==========================================
    window_size = 150
    kernel = np.ones(window_size) / window_size
    
    mse_tflaf_smooth = np.convolve(mse_tflaf, kernel, mode='valid')
    mse_hbo_smooth   = np.convolve(mse_hbo, kernel, mode='valid')
    
    mse_tflaf_dB = 10 * np.log10(mse_tflaf_smooth + 1e-12)
    mse_hbo_dB   = 10 * np.log10(mse_hbo_smooth + 1e-12)
    
    plt.figure(figsize=(9, 5))
    plt.plot(mse_tflaf_dB, label=f'TFLAF ($\mu={mu_tflaf}$)', color='#2980b9', linewidth=1.5, linestyle='--')
    plt.plot(mse_hbo_dB, label=f'HBO-TFLAF ($\mu_w={mu_w}, \mu_a={mu_a}$)', color='#e74c3c', linewidth=2)
    
    plt.title('Comparison of Learning Curves (MSE)', fontsize=12)
    plt.xlabel('Iterations', fontsize=10)
    plt.ylabel('MSE (dB)', fontsize=10)
    plt.grid(True, which='both', linestyle=':', alpha=0.7)
    plt.legend(fontsize=10)
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    run_simulation()